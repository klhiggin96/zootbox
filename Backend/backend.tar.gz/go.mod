module github.com/zootbox/backend

go 1.21

require (
	github.com/go-chi/chi/v5 v5.0.11
	github.com/google/uuid v1.5.0
	github.com/mattn/go-sqlite3 v1.14.19
	github.com/rs/zerolog v1.31.0
	github.com/stretchr/testify v1.8.4
)

require (
	github.com/davecgh/go-spew v1.1.1 // indirect
	github.com/mattn/go-colorable v0.1.13 // indirect
	github.com/mattn/go-isatty v0.0.20 // indirect
	github.com/pmezard/go-difflib v1.0.0 // indirect
	golang.org/x/sys v0.15.0 // indirect
	gopkg.in/yaml.v3 v3.0.1 // indirect
)
